export class CreateRecieptDto {}
